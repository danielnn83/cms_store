<?php
/**
 * @copyright Copyright (c) 2017 Usha Singhai Neo Informatique Pvt. Ltd
 * @license https://github.com/ushainformatique/yiichimp/blob/master/LICENSE.md
 */
$installed = true;
$siteName           = "admon";
$dsn                = 'mysql:host=localhost;port=3306;dbname=cms_db;';
$username           = 'cms_user';
$password           = 'ZVf31r8myu';
$debug              = false;
$environment        = 'dev';
$vendorPath         = '.';
$backendVendorPath  = '..';
