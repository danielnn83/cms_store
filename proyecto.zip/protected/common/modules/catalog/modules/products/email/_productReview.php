<p>
    Hello,<br/>
    {{customername}} has posted a new review on {{productname}}.
</p>
<p>
    The review is:<br/>
    {{review}}<br/><br/>
    Thanks,<br />
    System Admin
</p>