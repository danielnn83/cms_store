<p>Bienvenido {{fullName}}. Su cuenta ha sido creada con éxito en {{appname}}</p>

<p>La información de inicio de sesión es la siguiente:<br /><br/>
    <strong>Username:</strong> {{username}}<br />
    <strong>Password</strong>: {{password}}</p>

{{confirmemailLabel}}
{{confirmemail}}

Gracias,<br />
System Admin

