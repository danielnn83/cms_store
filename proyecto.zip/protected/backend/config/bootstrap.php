<?php
/*
 * Define aliases and constants on boostrtap of application
 */
