<p>Attn. System Admin</p>
<p>
    The following query is received
</p>
<p>
    Name: {{name}}<br/>
    Email: {{email}}<br/>
    Subject: {{subject}}<br/>
    Message: {{message}}
</p>