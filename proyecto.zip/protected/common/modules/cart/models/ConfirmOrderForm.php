<?php
/**
 * @copyright Copyright (C) 2016 Usha Singhai Neo Informatique Pvt. Ltd
 * @license https://www.gnu.org/licenses/gpl-3.0.html
 */
namespace cart\models;

use yii\base\Model;
/**
 * ConfirmOrderForm class file
 * 
 * @package cart\models
 * It might be used if there is need to configure extra parameters for review order.
 */
class ConfirmOrderForm extends Model
{
    
}
