<?php

$config = [
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'xqUcY0hduSy8mNCvRwXuo2ZGDzj7k1y5',
        ],
    ],
];
return $config;
