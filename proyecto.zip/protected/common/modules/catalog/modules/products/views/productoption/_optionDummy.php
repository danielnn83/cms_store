<div class="option-value-field-container option-value-dummy" style="display:none;">
    <div class="form-group">
        <div class="col-xs-8 col-xs-offset-2 input-group">
            <input type="text" class="form-control" name="ProductOptionValue[##rowCount##][value]"/>
            <a class="remove-optionvalue" href="#">
                <i class="fa fa-minus"></i>
            </a>
            <div class="help-block help-block-error "></div>
        </div>
    </div>
    <input type="hidden" name="ProductOptionValue[##rowCount##][id]" value="-1"/>
</div>