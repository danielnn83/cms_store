<?php
/**
 * @copyright Copyright (C) 2016 Usha Singhai Neo Informatique Pvt. Ltd
 * @license https://www.gnu.org/licenses/gpl-3.0.html
 */
$installed          = false;
$siteName           = 'My Application';
$dsn                = 'mysql:host=localhost;port=3306;dbname=demo;';
$username           = 'demo';
$password           = 'demo';
$debug              = false;
$environment        = 'production';
$vendorPath         = '.';
$backendVendorPath  = '..';