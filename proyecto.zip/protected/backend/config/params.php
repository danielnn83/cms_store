<?php
return [
    'passwordResetTokenExpire' => 3600,
];
