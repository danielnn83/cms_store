<div class="tab-pane active" id="tab-description">
    <?php echo $description;?>
</div> 
<?php echo $attributes;?>
<div id="tab-review" class="tab-pane">
    <?php echo $reviews;?>
</div>

